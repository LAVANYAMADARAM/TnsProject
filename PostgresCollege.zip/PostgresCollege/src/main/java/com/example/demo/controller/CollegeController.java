package com.example.demo.controller;


import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.College;

import com.example.demo.exception.ResourceNotFoundException;
import com.example.demo.repository.CollegeRepository;



@RestController
@RequestMapping("/api/v1/")
public class CollegeController {
	@Autowired
	   private CollegeRepository repository;

	//create user rest api
	@PostMapping("/college")
	public College createUser(@RequestBody College college) {
		return repository.save(college);
	}

	// get all user
	@GetMapping("/college")
	public List<College> getAllCollege(){
		return repository.findAll();
	}	
	// get user by id rest api
			@GetMapping("/college/{id}")
			public ResponseEntity<College> getCollegeById(@PathVariable Long id) {
				College college = repository.findById(id)
						.orElseThrow(() -> new ResourceNotFoundException("college not exist with id :" + id));
				return ResponseEntity.ok(college);
			}
			// update user rest api
			
			@PutMapping("/college/{id}")
			public ResponseEntity<College> updateUser(@PathVariable Long id, @RequestBody College collegeDetails){
				College college = repository.findById(id)
						.orElseThrow(() -> new ResourceNotFoundException("college not exist with id :" + id));
				college.setCollegeName(collegeDetails.getCollegeName());
				college.setLocation(collegeDetails.getLocation());

				College updatedCollege = repository.save(college);
				return ResponseEntity.ok(updatedCollege);
			}
			// delete user rest api
			@DeleteMapping("/college/{id}")
			public ResponseEntity<Map<String, Boolean>> deleteUser(@PathVariable Long id){
				College college = repository.findById(id)
						.orElseThrow(() -> new ResourceNotFoundException("college not exist with id :" + id));
				
				repository.delete(college);
				Map<String, Boolean> response = new HashMap<>();
				response.put("deleted", Boolean.TRUE);
				return ResponseEntity.ok(response);
			}
		}


			
				

